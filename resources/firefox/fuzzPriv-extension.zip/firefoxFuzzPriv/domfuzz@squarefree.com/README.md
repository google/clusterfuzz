fuzzPriv fuzzing helper extension

This is the legacy XUL add-on version. Continue to report issues, but this will eventually stop working entirely.

This should be working on nightly with the following prefs:

    user_pref("xpinstall.signatures.required", false);
    user_pref("extensions.legacy.enabled", true);

