// Copyright 2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <Python.h>
static int once = 0;
static PyObject *module_name;
static PyObject *py_module;
static PyObject *custom_mutator;


void initialize(){
  Py_Initialize();
  module_name = PyString_FromString("mutate");
  py_module = PyImport_Import(module_name);
  Py_DECREF(module_name);
  custom_mutator = PyObject_GetAttrString(py_module, "custom_mutator");
}
size_t LLVMFuzzerCustomMutator(uint8_t *data, size_t size, size_t max_size,
                               unsigned int seed) {

  // Initialize Python and load the mutate module.
  if (!once) {
    initialize();
    ++once;
  }

  // Create arguments tuple. - 5 parameters in custom_mutator.
  PyObject *py_args = PyTuple_New(5);

  // Add the data as an argument.
  PyObject *py_value = PyByteArray_FromStringAndSize((const char *)data, size);
  PyTuple_SetItem(py_args, 0, py_value);

  // Add title as an argument.
  const char * title = getenv("PIT_TITLE");
  if (!title) {
        fprintf(stderr, "Error: Invalid or Missing PIT_TITLE.\n");
        exit(1);
  }
  py_value = PyString_FromString(title);
  PyTuple_SetItem(py_args, 1, py_value);

  // Add the pit Path as an argument.
  const char * filename = getenv("PIT_FILENAME");
  if (!filename) {
        fprintf(stderr, "Error: Invalid or Missing PIT_FILENAME.\n");
        exit(1);
  }
  py_value = PyString_FromString(filename);
  PyTuple_SetItem(py_args, 2, py_value);

  // Add the max size as an argument.
  py_value = PyLong_FromSize_t(max_size);
  PyTuple_SetItem(py_args, 3, py_value);

  // Add the seed as an argument.
  py_value = PyLong_FromUnsignedLong((unsigned long)seed);
  PyTuple_SetItem(py_args, 4, py_value);

  // Call the function.
  py_value = PyObject_CallObject(custom_mutator, py_args);

  // Copy result back into Data's memory.
  size_t returned_size = PyByteArray_Size(py_value);
  memcpy(data, PyByteArray_AsString(py_value), returned_size);

  // Clean up
  Py_DECREF(py_args);
  Py_DECREF(py_value);

  return returned_size;
}