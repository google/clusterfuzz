# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""LLVM Fuzzer Custom Mutator entry point."""

from mutator import DataModelMutator
from parser import Parser
from Peach.Engine.engine import Engine


def custom_mutator(data, title, pit_path, max_size, seed):
  """Entry point for LLVMFuzzerCustomMutator."""
  strdata = str(data)
  assert max_size >= 0
  # Initialize Peach.
  peachrun = Engine()
  peachrun.SEED = seed
  peachrun.mutators = []

  # Parse the data using the peach pit.
  parser = Parser(pit_path, title)
  data_model = parser.parse(strdata)

  # Mutate the datatree.
  mutator = DataModelMutator(data_model)
  # TODO(mpherman): Figure out best min and max mutations.
  mutator.random_mutation(5, 10, seed)
  result = data_model.getValue()

  # Truncate the data if it is too large.
  return bytearray(result)[:max_size]
