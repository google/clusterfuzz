# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Data Model Mutator."""

from builtins import object
from builtins import range
from Peach.Engine.engine import Engine
from Peach.Mutators import array
from Peach.Mutators import blob
from Peach.Mutators import datatree
from Peach.Mutators import number
from Peach.Mutators import size
from Peach.Mutators import string
import random


class DataModelMutator(object):
  """Create a mutator that will apply mutations to a given data model."""

  def __init__(self, data_model):
    self._populate_mutators()
    self._data_model = data_model
    self._nodes = data_model.getAllChildDataElements()

    # field_mutators is a dictionary for nodes to applicable mutators.
    self._field_mutators = {}

    # Populate field_mutators. Do this in init so if random_mutations is called
    # multiple times, this only needs to be done once.
    for node in self._nodes:
      if not node.isMutable:
        continue
      mutators = []
      self._field_mutators[node.getFullname()] = mutators
      for mutator in Engine.context.mutators:
        if mutator.supportedDataElement(node):
          # This is taking weights from Peaches Mutation Strategies.
          for _ in range(mutator.weight**4):
            mutators.append(mutator(Engine.context, node))

  def random_mutation(self, min_mutations, max_mutations, seed):
    """Perform a series of random mutations."""
    rand = random.Random()
    rand.seed(seed)

    # Make sure that mutations <= self._nodes.
    if max_mutations > len(self._nodes):
      max_mutations = len(self._nodes)
    if min_mutations > len(self._nodes):
      min_mutations = 0

    # Grab fields at random.
    fields = rand.sample(self._nodes, rand.randint(min_mutations,
                                                   max_mutations))
    # Perform mutations on fields.
    for node in fields:
      try:
        mutator = rand.choice(self._field_mutators[node.getFullname()])

        # Since we are applying multiple mutations sometimes a
        # mutation will fail. We should ignore those failures.
        mutator.randomMutation(node, rand)
      except:
        pass

  def _populate_mutators(self):
    """This method adds all of the Peach mutators to the current Engine."""
    # Array Mutators.
    Engine.context.mutators.append(array.ArrayVarianceMutator)
    Engine.context.mutators.append(array.ArrayNumericalEdgeCasesMutator)
    Engine.context.mutators.append(array.ArrayReverseOrderMutator)
    Engine.context.mutators.append(array.ArrayRandomizeOrderMutator)
    # Blob Mutators.
    Engine.context.mutators.append(blob.DWORDSliderMutator)
    Engine.context.mutators.append(blob.BitFlipperMutator)
    Engine.context.mutators.append(blob.BlobMutator)
    # Datatree Mutators.
    Engine.context.mutators.append(datatree.DataTreeRemoveMutator)
    Engine.context.mutators.append(datatree.DataTreeDuplicateMutator)
    Engine.context.mutators.append(datatree.DataTreeSwapNearNodesMutator)
    # Number Mutators.
    Engine.context.mutators.append(number.NumericalVarianceMutator)
    Engine.context.mutators.append(number.NumericalEdgeCaseMutator)
    Engine.context.mutators.append(number.FiniteRandomNumbersMutator)
    Engine.context.mutators.append(number.NumericalEvenDistributionMutator)
    # Size Mutators.
    Engine.context.mutators.append(size.SizedVarianceMutator)
    Engine.context.mutators.append(size.SizedNumericalEdgeCasesMutator)
    Engine.context.mutators.append(size.SizedVarianceMutator)
    Engine.context.mutators.append(size.SizedDataVarianceMutator)
    Engine.context.mutators.append(size.SizedDataNumericalEdgeCasesMutator)
    # String Mutators.
    Engine.context.mutators.append(string.StringCaseMutator)
    Engine.context.mutators.append(string.UnicodeStringsMutator)
    Engine.context.mutators.append(string.ValidValuesMutator)
    Engine.context.mutators.append(string.UnicodeBomMutator)
    Engine.context.mutators.append(string.UnicodeBadUtf8Mutator)
    Engine.context.mutators.append(string.UnicodeUtf8ThreeCharMutator)
    Engine.context.mutators.append(string.StringMutator)
    Engine.context.mutators.append(string.XmlW3CMutator)
    Engine.context.mutators.append(string.PathMutator)
    Engine.context.mutators.append(string.HostnameMutator)
    Engine.context.mutators.append(string.IpAddressMutator)
    Engine.context.mutators.append(string.TimeMutator)
    Engine.context.mutators.append(string.DateMutator)
    Engine.context.mutators.append(string.FilenameMutator)
