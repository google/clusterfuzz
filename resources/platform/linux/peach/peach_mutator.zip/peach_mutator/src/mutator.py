# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Data Model Mutator."""

from builtins import object
from builtins import range
from Peach.Engine.engine import Engine
from Peach.Mutators import array
from Peach.Mutators import blob
from Peach.Mutators import datatree
from Peach.Mutators import number
from Peach.Mutators import size
from Peach.Mutators import string
import random


class DataModelMutator(object):
  """Create a mutator that will apply mutations to a given data model."""

  def __init__(self, data_model, seed):
    self._populate_mutators()
    self._data_model = data_model
    self._nodes = data_model.getAllChildDataElements()
    self._seed = seed

    # field_mutators is a dictionary for nodes to applicable mutators.
    self._field_mutators = {}

    # Populate field_mutators. Do this in init so if random_mutations is called
    # multiple times, this only needs to be done once.
    for node in self._nodes:
      if not node.isMutable:
        # TODO(mpherman): Add logging to see how often this occurs
        continue
      mutators = []
      self._field_mutators[node.getFullname()] = mutators
      for mutator in Engine.context.mutators:
        if mutator.supportedDataElement(node):
          # This is taking weights from Peaches Mutation Strategies.
          for _ in range(mutator.weight**4):
            mutators.append(mutator(Engine.context, node))

  def random_mutation(self, min_mutations, max_mutations):
    """Perform a series of random mutations."""
    rand = random.Random()
    rand.seed(self._seed)

    # Make sure that mutations <= self._nodes.
    if max_mutations > len(self._nodes):
      max_mutations = len(self._nodes)
    if min_mutations > len(self._nodes):
      min_mutations = 0

    # Grab fields at random.
    fields = rand.sample(self._nodes, rand.randint(min_mutations,
                                                   max_mutations))
    # Perform mutations on fields.
    for node in fields:
      try:
        mutator = rand.choice(self._field_mutators[node.getFullname()])

        # Since we are applying multiple mutations sometimes a
        # mutation will fail. We should ignore those failures.
        mutator.randomMutation(node, rand)
      except:
        # TODO(mpherman): Add logging to see how often this occurs
        pass

  def _populate_mutators(self):
    """This method adds all of the Peach mutators to the current Engine."""
    # Array Mutators.
    mutators = []
    mutators.append(array.ArrayVarianceMutator)
    mutators.append(array.ArrayNumericalEdgeCasesMutator)
    mutators.append(array.ArrayReverseOrderMutator)
    mutators.append(array.ArrayRandomizeOrderMutator)
    # Blob Mutators.
    mutators.append(blob.DWORDSliderMutator)
    mutators.append(blob.BitFlipperMutator)
    mutators.append(blob.BlobMutator)
    # Datatree Mutators.
    mutators.append(datatree.DataTreeRemoveMutator)
    mutators.append(datatree.DataTreeDuplicateMutator)
    mutators.append(datatree.DataTreeSwapNearNodesMutator)
    # Size Mutators.
    mutators.append(size.SizedVarianceMutator)
    mutators.append(size.SizedNumericalEdgeCasesMutator)
    mutators.append(size.SizedVarianceMutator)
    mutators.append(size.SizedDataVarianceMutator)
    mutators.append(size.SizedDataNumericalEdgeCasesMutator)
    # String Mutators.
    mutators.append(string.StringCaseMutator)
    mutators.append(string.UnicodeStringsMutator)
    mutators.append(string.ValidValuesMutator)
    mutators.append(string.UnicodeBomMutator)
    mutators.append(string.UnicodeBadUtf8Mutator)
    mutators.append(string.UnicodeUtf8ThreeCharMutator)
    mutators.append(string.StringMutator)
    mutators.append(string.XmlW3CMutator)
    mutators.append(string.PathMutator)
    mutators.append(string.HostnameMutator)
    mutators.append(string.IpAddressMutator)
    mutators.append(string.TimeMutator)
    mutators.append(string.DateMutator)
    mutators.append(string.FilenameMutator)
    Engine.context.mutators = mutators
